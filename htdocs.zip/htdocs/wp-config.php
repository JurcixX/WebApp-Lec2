<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'QJ08&(!YykC(zm,[Ln>$8JIUEY[`QJwh?cEJ6XAtl|TAA)ou2nQsk,TMtEVz=GWd' );
define( 'SECURE_AUTH_KEY',  'n:ZjE__1fA.|fXA+*1j<w6+T:xT.kp:+z%KFJZMGdKnR56ST:ZS5x>K,X]?@=E4)' );
define( 'LOGGED_IN_KEY',    '`5{_$6$ABM1{;+ A7Qo6Bw?!%BZ}3u<;Ji5z2!trrMg?ZDiGXj9Zy)=~:i3it4`f' );
define( 'NONCE_KEY',        '[b4I~!H.z%#DS|5Tke*$9]sM_]daBpi4;Q4{Te3B#zs;weS/S>8mV 4rFr9JS3hR' );
define( 'AUTH_SALT',        '@ID5N^~&F>z$$fubPIy,.EJ@6YfsOV]LX%2x=g)4SM0q7hb<MHEs&*f<PiL?DU(t' );
define( 'SECURE_AUTH_SALT', '3%=LW{u$;[fhEd9ibt_!STR`BP3uxOd;@oicDuO%&wi=gG!cSTz%M+Wn5,+ZDr=1' );
define( 'LOGGED_IN_SALT',   'ips^M,R4cmN;4_,=_?j.0>(qQE{?kKo:PklvD7><:=J&{G7Jz!cUU+r$4?I9/qrM' );
define( 'NONCE_SALT',       '`Id l}K>E%7Q<g:2.E<E<P!]N KgXed[g#Yph}7(Rkw`RNgsL)gO?VkE$1nWedJe' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
